import aiosqlite
from config import DB_PATH

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price INTEGER NOT NULL,
                category TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                items_json TEXT NOT NULL,
                total_amount INTEGER NOT NULL,
                status TEXT DEFAULT 'paid',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        await db.commit()
        # Тестовые данные
        async with db.execute("SELECT COUNT(*) FROM items") as cursor:
            if (await cursor.fetchone())[0] == 0:
                items = [
                    ("Шаурма классическая (обычная)", 22000, "shaurma"),
                    ("Шаурма классическая (большая)", 25000, "shaurma"),
                    ("Шаурма сырная (обычная)", 24000, "shaurma"),
                    ("Шаурма сырная (большая)", 27000, "shaurma"),
                    ("Кола", 6000, "drinks"),
                    ("Спрайт", 6000, "drinks"),
                    ("Вода", 3000, "drinks"),
                    ("Соус сырный", 3000, "sauces"),
                    ("Соус чесночный", 2000, "sauces"),
                ]
                await db.executemany("INSERT INTO items (name, price, category) VALUES (?, ?, ?)", items)
                await db.commit()

async def get_items_by_category(category: str):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id, name, price FROM items WHERE category = ?", (category,)) as cursor:
            return await cursor.fetchall()

async def create_order(user_id: int, items_json: str, total_amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO orders (user_id, items_json, total_amount) VALUES (?, ?, ?)",
            (user_id, items_json, total_amount)
        )
        await db.commit()
        return cursor.lastrowid

async def get_orders(limit=10):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT ?", (limit,)) as cursor:
            return await cursor.fetchall()