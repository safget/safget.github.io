import json
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.exceptions import AiogramError

from config import ADMIN_IDS
from database import *
from keyboards import *

router = Router()

# Временное хранилище корзин (в реальном проекте лучше в БД, но для демо сойдёт)
user_carts = {}

async def safe_delete(call: CallbackQuery):
    try:
        await call.message.delete()
    except AiogramError:
        pass

@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "🥙 Добро пожаловать в <b>Шаурма House</b>!\n"
        "Закажите онлайн через удобное меню.",
        parse_mode="HTML",
        reply_markup=main_menu()
    )

# --- Обработка Mini App ---
@router.message(F.content_type == "web_app_data")
async def handle_web_app_order(message: Message):
    data = json.loads(message.web_app_data.data)
    items = data.get("items", [])
    total = data.get("total", 0)

    if not items:
        await message.answer("❌ Заказ пуст.")
        return

    user_id = message.from_user.id
    items_json = json.dumps(items, ensure_ascii=False)
    order_id = await create_order(user_id, items_json, total)

    # Уведомление клиенту
    await message.answer(
        f"✅ <b>Заказ #{order_id} принят!</b>\n"
        f"Сумма: {total/100:.0f} ₽\n"
        "Скоро начнём готовить. Спасибо!",
        parse_mode="HTML"
    )

    # Уведомление админам
    items_text = ", ".join(f"{item['name']} x{item['quantity']}" for item in items)
    for admin_id in ADMIN_IDS:
        try:
            await message.bot.send_message(
                admin_id,
                f"🔔 <b>Новый заказ #{order_id}</b>\n"
                f"💰 Сумма: {total/100:.0f} ₽\n"
                f"📦 {items_text}",
                parse_mode="HTML"
            )
        except Exception:
            pass

# --- Текстовое меню (старый способ) ---
@router.callback_query(F.data == "back_to_main")
async def handle_back_to_main(call: CallbackQuery):
    await safe_delete(call)
    await call.message.answer("Главное меню:", reply_markup=main_menu())
    await call.answer()

@router.callback_query(F.data == "back_to_categories")
async def show_categories(call: CallbackQuery):
    await safe_delete(call)
    await call.message.answer("📋 Выберите категорию:", reply_markup=categories_menu())
    await call.answer()

@router.callback_query(F.data.startswith("cat_"))
async def show_items(call: CallbackQuery):
    category = call.data.split("_")[1]
    items = await get_items_by_category(category)
    if not items:
        await call.answer("В этой категории пока нет товаров.")
        return
    cat_names = {"shaurma": "🥙 Шаурма", "drinks": "🥤 Напитки", "sauces": "🧂 Соусы"}
    await safe_delete(call)
    await call.message.answer(f"Товары в категории «{cat_names.get(category, category)}»:", reply_markup=items_menu(items, category))
    await call.answer()

@router.callback_query(F.data.startswith("add_"))
async def add_item(call: CallbackQuery):
    item_id = int(call.data.split("_")[1])
    user_id = call.from_user.id
    if user_id not in user_carts:
        user_carts[user_id] = {}
    cart = user_carts[user_id]
    cart[item_id] = cart.get(item_id, 0) + 1
    # Получаем название товара для уведомления
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT name FROM items WHERE id=?", (item_id,)) as cursor:
            item = await cursor.fetchone()
            name = item[0] if item else "Товар"
    await call.answer(f"✅ {name} добавлен в корзину!")

@router.callback_query(F.data == "view_cart")
async def view_cart(call: CallbackQuery):
    user_id = call.from_user.id
    cart = user_carts.get(user_id, {})
    if not cart:
        await safe_delete(call)
        await call.message.answer("🛒 Корзина пуста.", reply_markup=back_to_main())
        return
    # Получаем данные о товарах
    text = "🛒 <b>Ваша корзина:</b>\n\n"
    total = 0
    for item_id, qty in cart.items():
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT name, price FROM items WHERE id=?", (item_id,)) as cursor:
                item = await cursor.fetchone()
                if item:
                    subtotal = item[1] * qty
                    text += f"• {item[0]} x{qty} — {subtotal/100:.0f} ₽\n"
                    total += subtotal
    text += f"\n💰 <b>Итого: {total/100:.0f} ₽</b>"
    await safe_delete(call)
    await call.message.answer(text, reply_markup=cart_keyboard(), parse_mode="HTML")
    await call.answer()

@router.callback_query(F.data == "clear_cart")
async def clear_cart_handler(call: CallbackQuery):
    user_carts.pop(call.from_user.id, None)
    await safe_delete(call)
    await call.message.answer("🗑 Корзина очищена.", reply_markup=back_to_main())
    await call.answer()

@router.callback_query(F.data == "checkout")
async def checkout(call: CallbackQuery):
    user_id = call.from_user.id
    cart = user_carts.get(user_id, {})
    if not cart:
        await call.answer("Корзина пуста!")
        return

    items_list = []
    total = 0
    for item_id, qty in cart.items():
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT name, price FROM items WHERE id=?", (item_id,)) as cursor:
                item = await cursor.fetchone()
                if item:
                    subtotal = item[1] * qty
                    total += subtotal
                    items_list.append({"name": item[0], "price": item[1], "quantity": qty})

    items_json = json.dumps(items_list, ensure_ascii=False)
    order_id = await create_order(user_id, items_json, total)
    user_carts.pop(user_id, None)

    await safe_delete(call)
    await call.message.answer(
        f"✅ <b>Заказ #{order_id} оплачен!</b>\n"
        f"Сумма: {total/100:.0f} ₽\n"
        "Ожидайте, скоро начнём готовить. Спасибо! 🥙",
        parse_mode="HTML"
    )

    items_text = ", ".join(f"{item['name']} x{item['quantity']}" for item in items_list)
    for admin_id in ADMIN_IDS:
        try:
            await call.bot.send_message(admin_id, f"🔔 Новый заказ #{order_id}\n💰 {total/100:.0f} ₽\n📦 {items_text}")
        except Exception:
            pass
    await call.answer("Заказ оформлен!", show_alert=True)

# Админ-панель
@router.message(Command("admin"))
async def admin_cmd(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("🔐 Панель управления", reply_markup=admin_keyboard())

@router.callback_query(F.data == "admin_orders")
async def admin_orders(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа")
        return
    orders = await get_orders()
    if not orders:
        await safe_delete(call)
        await call.message.answer("Заказов пока нет.", reply_markup=admin_keyboard())
        return
    text = "<b>Последние заказы:</b>\n\n"
    for order in orders:
        items = json.loads(order[2])
        items_text = ", ".join(f"{item['name']} x{item['quantity']}" for item in items)
        text += f"🆔 <b>Заказ #{order[0]}</b>\n💰 {order[3]/100:.0f} ₽\n📦 {items_text}\n\n"
    await safe_delete(call)
    await call.message.answer(text, reply_markup=admin_keyboard(), parse_mode="HTML")
    await call.answer()