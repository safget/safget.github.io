from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from config import MINI_APP_URL

def main_menu():
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Открыть меню", web_app=WebAppInfo(url=MINI_APP_URL))],
            [KeyboardButton(text="🛒 Корзина (текст)"), KeyboardButton(text="❓ FAQ")],
            [KeyboardButton(text="📞 Контакты")]
        ],
        resize_keyboard=True
    )
    return kb

def categories_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🥙 Шаурма", callback_data="cat_shaurma")],
        [InlineKeyboardButton(text="🥤 Напитки", callback_data="cat_drinks")],
        [InlineKeyboardButton(text="🧂 Соусы", callback_data="cat_sauces")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")]
    ])

def items_menu(items, category):
    builder = InlineKeyboardMarkup(inline_keyboard=[])
    for item_id, name, price in items:
        price_rub = price / 100
        builder.inline_keyboard.append([
            InlineKeyboardButton(text=f"{name} — {price_rub:.0f} ₽", callback_data=f"add_{item_id}")
        ])
    builder.inline_keyboard.append([InlineKeyboardButton(text="🔙 Назад к категориям", callback_data="back_to_categories")])
    return builder

def cart_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Оформить заказ", callback_data="checkout")],
        [InlineKeyboardButton(text="🗑 Очистить корзину", callback_data="clear_cart")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")]
    ])

def back_to_main():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Главное меню", callback_data="back_to_main")]
    ])

def admin_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Заказы", callback_data="admin_orders")],
        [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")]
    ])